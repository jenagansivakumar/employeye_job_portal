import { Router } from "express";
import fetchUser from "../controllers/fetchUserController.js";
import serveData from "../controllers/serveDataController.js";
import postUser from "../controllers/postUserController.js";







const router = Router()



router.get("/fetch", fetchUser )
router.get("/data", serveData)
router.post("/create", postUser)


export default router