import { Request, Response } from "express";
import { Data, DataArrayInterface, DataInterface } from "../models/Data.js";




const serveData = (req: Request, res: Response) => {

    const dataArray: Data[]= []
    for (let i =0; i < 10; i++){
        const data = {
         message: "Hello from the backend",
         timestamp: new Date(),
         id: i
        }
        dataArray.push(data)
    }
    res.status(200).json(dataArray)

}


export default serveData