import { Request, Response } from "express";




const postUser = (req: Request, res: Response) => {
    console.log(req.body)
    
    try {
        const {name, email} = req.body
        if (!name || !email) {
            return res.status(400).json({message: "Name and Email must be present"})
        }
        res.status(201).json({message: "Data has been received: ", name, email})
    } catch (error) {
        res.status(500).json({error: "Error fetching data"})
    }
}

export default postUser